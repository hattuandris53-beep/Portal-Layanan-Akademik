# Portal Layanan Akademik

Tugas Pertemuan 5 – Responsive & Accessible Web Client.

- **URL aplikasi:** _isi link GitHub Pages / Netlify_
- **Repository:** _isi link GitHub_

## Cara menjalankan
Tidak perlu XAMPP atau server khusus. Buka `index.html` langsung di browser,
atau gunakan ekstensi *Live Server* di VS Code.

## Struktur
```
index.html
css/styles.css
img/           logo-portal.svg, alur-layanan.svg
evidence/      screenshot DevTools
```

## Keputusan desain
| Keputusan | Alasan |
|---|---|
| Landmark `header`, `nav`, `main`, `section`, `article`, `footer` | Pembaca layar bisa melompat antarbagian halaman. |
| Heading: h1 portal → h2 tiap bagian → h3 tiap kartu | Urutan mengikuti struktur informasi, bukan ukuran visual. |
| CSS mobile-first, satu kolom lalu breakpoint 40em dan 64em | Breakpoint dipilih saat kartu dan form mulai renggang, bukan berdasarkan nama perangkat. |
| Kartu memakai CSS Grid, nav dan tombol memakai Flexbox | Grid cocok untuk kolom kartu, Flexbox untuk baris tunggal. |
| Link kartu bertuliskan "Ajukan Surat Aktif Kuliah", bukan "Klik di sini" | Teks link tetap bermakna saat dibaca di luar konteks. |
| Skip link, `:focus-visible` tebal, target sentuh minimal 44px | Akses keyboard dan layar sentuh. |
| `label for` + `id` pada semua field, `fieldset/legend` pada radio | Label terasosiasi dan grup terbaca jelas. |
| `alt=""` pada logo di header | Logo dekoratif: teks "Portal Layanan Akademik" sudah ada di sebelahnya. |
| `alt` deskriptif pada `alur-layanan.svg` | Gambar informatif: isinya tiga langkah alur layanan. |
| Tanpa JavaScript, validasi memakai atribut HTML | `required`, `type="email"`, `pattern`, `minlength`, `maxlength`. |

## Hasil pemeriksaan DevTools
| Pemeriksaan | Hasil | Bukti |
|---|---|---|
| Responsive Mode 360 px | _isi: ada/tidak horizontal scroll_ | `evidence/360.png` |
| Responsive Mode 768 px | _isi_ | `evidence/768.png` |
| Responsive Mode 1280 px | _isi_ | `evidence/1280.png` |
| Elements / Inspector | _isi: landmark dan label terasosiasi terlihat di DOM_ | `evidence/elements.png` |
| Network (reload) | _isi: jumlah request, ada 404 atau tidak_ | `evidence/network.png` |
| Accessibility tree | _isi: role landmark dan nama accessible form_ | `evidence/a11y.png` |
| Uji email salah format | _isi: pesan validasi browser muncul_ | `evidence/validasi.png` |
| Uji keyboard (Tab) | _isi: fokus terlihat di semua kontrol_ | `evidence/keyboard.png` |

## Temuan debugging
_Tulis 2–3 temuan nyata dari pengujianmu, misalnya masalah yang kamu temukan dan cara memperbaikinya._
